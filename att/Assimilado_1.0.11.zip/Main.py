from typing import Final 
import os
from dotenv import load_dotenv
from discord import Intents, Client, Message
from responses import get_response

load_dotenv()
TOKEN: Final[str] = os.getenv('DISCORD_TOKEN')

# SETUP
intents: Intents = Intents.default()
intents.message_content = True
client: Client = Client(intents=intents)

# FUNCIONALIDADE
async def send_message(message: Message, user_message: str) -> None:
    if not user_message:
        print('Mensagem vazia, intent não habilitado')
        return

    response: str = get_response(user_message)
    
    if response:  # Só responde se houver um comando válido
        try:
            await message.channel.send(response)  # Agora sempre responde no canal
        except Exception as e:
            print(f"Erro ao enviar mensagem: {e}")

# LOGIN DO BOT
@client.event
async def on_ready():
    print(f'Bot {client.user} está online!')

@client.event
async def on_message(message: Message):
    if message.author == client.user:
        return  # Evita que o bot responda a si mesmo

    username: str = str(message.author)
    user_message: str = message.content
    channel: str = str(message.channel)

    print(f'[{channel}] {username}: "{user_message}"')
    await send_message(message, user_message)

client.run(TOKEN)
