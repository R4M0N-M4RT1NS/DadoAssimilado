from random import randint
import re

# Mapeamento de emojis personalizados usando os IDs fornecidos
DICE_SYSTEM_EMOJIS = {
    1: "*Nada*",
    2: "*Nada*",
    3: "<:Pressao:1357013346968141921>",
    4: "<:Pressao:1357013346968141921> <:Adaptacao:1357013371882438737>",
    5: "<:Pressao:1357013346968141921> <:Adaptacao:1357013371882438737>",
    6: "<:Sucesso:1357013314109964350>",
    7: "<:Sucesso:1357013314109964350> <:Sucesso:1357013314109964350>",
    8: "<:Sucesso:1357013314109964350> <:Adaptacao:1357013371882438737>",
    9: "<:Sucesso:1357013314109964350> <:Adaptacao:1357013371882438737> <:Pressao:1357013346968141921>",
    10: "<:Sucesso:1357013314109964350> <:Sucesso:1357013314109964350> <:Pressao:1357013346968141921>",
    11: "<:Sucesso:1357013314109964350> <:Adaptacao:1357013371882438737> <:Adaptacao:1357013371882438737> <:Pressao:1357013346968141921>",
    12: "<:Pressao:1357013346968141921> <:Pressao:1357013346968141921>"
}

def roll_dice(num_dice: int, num_sides: int) -> list:
    """ Rola os dados e retorna uma lista com os resultados individuais. """
    return [randint(1, num_sides) for _ in range(num_dice)]

def process_roll(expression: str, system_mode: bool) -> list:
    """ Processa uma única rolagem de dados e aplica operações matemáticas. Retorna uma lista de resultados. """
    match = re.match(r'(\d*)d(\d+)([+\-*/]\d+)?', expression)

    num_dice, num_sides, operation = match.groups()
    num_dice = int(num_dice) if num_dice else 1
    num_sides = int(num_sides)

    # Rola os dados
    rolls = roll_dice(num_dice, num_sides)
    roll_total = sum(rolls)
    final_result = roll_total
    operation_str = ""

    if operation:
        operator = operation[0]  # Pega o operador (+, -, *, /)
        value = int(operation[1:])  # Pega o número depois do operador

        # Realiza a operação matemática
        if operator == "+":
            final_result += value
        elif operator == "-":
            final_result -= value
        elif operator == "*":
            final_result *= value
        elif operator == "/":
            final_result = int(final_result / value)  # Evita números quebrados
            
        operation_str = f"Total inicial: {roll_total} {operator} {value} = {final_result}"

    # Se for um dado do sistema, usa o resultado final para os emojis
    if system_mode and num_sides in {6, 10, 12}:
        emoji_result = DICE_SYSTEM_EMOJIS.get(final_result, "*Nada*")
        result_str = f"Resultado = {final_result} : {emoji_result}"
    else:
        result_str = f"Resultado = {final_result}"

    return [operation_str, result_str] if operation else [result_str]

def get_response(user_input: str) -> str:
    """ Processa várias rolagens separadas por quebras de linha. """
    lines = user_input.strip().split("\n")
    responses = []

    for line in lines:
        lowered = line.lower().strip()
        if not lowered:
            continue

        system_mode = lowered.startswith('!')
        if system_mode:
            lowered = lowered[1:]  # Remove o '!' para processar normalmente

        multiple_match = re.match(r'(\d+)#(.+)', lowered)
        if multiple_match:
            num_repeats, expression = multiple_match.groups()
            num_repeats = int(num_repeats)
            roll_results = [result for _ in range(num_repeats) for result in process_roll(expression, system_mode)]
            responses.append("\n".join(roll_results))  # Junta os resultados da mesma rolagem sem linha vazia
        else:
            responses.append("\n".join(process_roll(lowered, system_mode)))  # Separa diferentes rolagens com linha vazia

    return "\n\n".join(responses)  # Mantém uma linha vazia entre diferentes rolagens
